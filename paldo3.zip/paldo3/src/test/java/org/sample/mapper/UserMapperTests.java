package org.sample.mapper;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sample.domain.UserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class UserMapperTests {

	@Autowired
	private UserMapper userMapper;
	
	@Test
	public void testRead() {
		log.info(userMapper.readUser(19L));
	}
	
	@Test
	public void testInsert() {
		UserVO vo = UserVO.builder()
				.nickname("testname")
				.pwd("1234")
				.email("test@test.test")
				.build();
		
		log.info(vo);
		userMapper.insertUser(vo);
	}
	
	@Test
	public void testUpdate() {
		UserVO vo = UserVO.builder()
				.userid(21L)
				.nickname("testname2")
				.pwd("12345")
				.email("test2@test.test")
				.build();
		userMapper.updateUser(vo);
	}
	
	@Test
	public void testDelete() {
		int result = userMapper.deleteUser(21L);
		log.info("result >>>>>>>>>>>>>" + result); //1이 나오면 성공, 0이 나오면 실패
	}

}
