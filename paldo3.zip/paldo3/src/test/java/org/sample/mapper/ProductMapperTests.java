package org.sample.mapper;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sample.domain.ProductVO;
import org.sample.domain.UserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.extern.log4j.Log4j;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ProductMapperTests {

	
	@Autowired
	private ProductMapper mapper;
	
	@Test
	public void testread() {
		log.info(mapper.readProduct(1L));
	}
	
	@Test
	public void testinsert() {
		ProductVO vo = ProductVO.builder()
				.description("test")
				.price(50000L)
				.condition("C")
				.brand("애플")
				.modelName("아이폰8")
				.build();
		mapper.insertProduct(vo);
	}
	@Test
	public void testUpdate() {
		ProductVO vo = ProductVO.builder()
				.productid(4L)
				.description("test2")
				.price(50000L)
				.condition("C급")
				.brand("애플")
				.modelName("아이폰8")
				.build();
		mapper.updateProduct(vo);
	}
	
	@Test
	public void testdelete() {
		int result = mapper.deleteProduct(4L);
		log.info("result >>>>>>>>>>>>>" + result);
	}

}
