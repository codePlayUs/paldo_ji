package org.sample.mapper;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sample.domain.BoardVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.sample.mapper.BoardMapper;
import org.sample.mapper.BoardMapperTests;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardMapperTests {

	@Autowired
	private BoardMapper mapper;
	
	@Test
	public void testRead() {
		log.info(mapper.readBoard(7L));
	}
	@Test
	public void testinstert() {
		BoardVO vo = BoardVO.builder()
				.productid(4L)
				.userid(4L)
				.status("안팔아")
				.title("테스트")
				.build();
		
		mapper.insertBoard(vo);
	}
	@Test
	public void testupdate() {
		BoardVO vo = BoardVO.builder()
				.boardid(7L)
				.productid(3L)
				.userid(3L)
				.status("안팔아")
				.title("테스트")
				.build();
		
		mapper.updateBoard(vo);
	}

	@Test
	public void testGetList() {
		List<BoardVO> list = mapper.getList();

		for(BoardVO vo : list)
			log.info(vo);
	}
	
	@Test
	public void testdelete() {
		int result = mapper.deleteBoard(7L);
		log.info("result >>>>>>>>>>>>>" + result); //1이 나오면 성공, 0이 나오면 실패
	}

}
