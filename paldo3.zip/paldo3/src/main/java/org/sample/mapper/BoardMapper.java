package org.sample.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.sample.domain.BoardVO;
import org.sample.domain.Criteria;

public interface BoardMapper {

	public int insertBoard(BoardVO board);

	public BoardVO readBoard(@Param("boardid") Long boardid);

	public int updateBoard(BoardVO board);

	public int deleteBoard(@Param("boardid") Long boardid);
    
	public List<BoardVO> selectAll(Criteria cri);
	
	public List<BoardVO> getListWithPaging(Criteria cri);
	
	public int countTotal(Criteria cri);
	
//	public List<BoardVO> searchTest(Map<String, Map<String,String>> map);
	
}
