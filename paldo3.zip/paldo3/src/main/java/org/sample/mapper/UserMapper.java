package org.sample.mapper;

import org.apache.ibatis.annotations.Param;
import org.sample.domain.UserVO;

public interface UserMapper {
	
	public int insertUser(UserVO user);

	public UserVO readBoard(@Param("userid") Long userid);

	public int updateUser(UserVO user);

	public int deleteUser(@Param("userid") Long userid);
}
