package org.sample.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.sample.domain.ImgPathVO;

public interface ImgPathMapper {

	public int insertImgPath(ImgPathVO imgPath);

	public List<ImgPathVO> readImgPath(@Param("productid") Long productid);

    public int deleteImgPath(@Param("imgid") Long imgid);
}
