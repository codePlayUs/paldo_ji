package org.sample.service;

import java.util.List;

import org.sample.domain.BoardVO;
import org.sample.domain.Criteria;
import org.sample.domain.ImgPathVO;
import org.sample.domain.ProductVO;
import org.sample.domain.UserVO;
import org.sample.mapper.BoardMapper;
import org.sample.mapper.ImgPathMapper;
import org.sample.mapper.ProductMapper;
import org.sample.mapper.UserMapper;

public class BoardServiceImpl implements BoardService {

    private BoardMapper boardMapper;
    private ImgPathMapper imgPathMapper;
    private ProductMapper productMapper;
    private UserMapper userMapper;

    // 의존성 주입 (Setter Injection)
    public void setBoardMapper(BoardMapper boardMapper) {
        this.boardMapper = boardMapper;
    }

    public void setImgPathMapper(ImgPathMapper imgPathMapper) {
        this.imgPathMapper = imgPathMapper;
    }

    public void setProductMapper(ProductMapper productMapper) {
        this.productMapper = productMapper;
    }

    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public void register(BoardVO board) {
        boardMapper.insertBoard(board);  // 게시글 등록
    }

    @Override
    public BoardVO get(Long pno) {
        return boardMapper.readBoard(pno);  // 게시글 조회
    }

    @Override
    public boolean modify(BoardVO board) {
        return boardMapper.updateBoard(board) > 0;  // 게시글 수정
    }

    @Override
    public boolean remove(Long pno) {
        return boardMapper.deleteBoard(pno) > 0;  // 게시글 삭제
    }

    @Override
    public List<BoardVO> getList(Criteria cri) {
        return boardMapper.selectAll(cri);  // 게시글 리스트 조회
    }

    @Override
    public int getTotal(Criteria cri) {
        return boardMapper.countTotal(cri);  // 전체 게시글 수 조회
    }
/*
    @Override
    public List<BoardVO> getAppleList() {
        return boardMapper.selectByBrand("Apple");  // Apple 브랜드 게시글 조회
    }

    @Override
    public List<BoardVO> getSamsungList() {
        return boardMapper.selectByBrand("Samsung");  // Samsung 브랜드 게시글 조회
    }

    @Override
    public List<BoardVO> getSonyList() {
        return boardMapper.selectByBrand("Sony");  // Sony 브랜드 게시글 조회
    }

    @Override
    public List<BoardVO> getOtherList() {
        return boardMapper.selectByBrand("Other");  // Other 브랜드 게시글 조회
    }
*/
    @Override
    public void registerImgPath(ImgPathVO imgPath) {
        imgPathMapper.insertImgPath(imgPath);  // 이미지 경로 등록
    }

    @Override
    public void registerProduct(ProductVO product) {
        productMapper.insertBoard(product);  // 상품 등록
    }

    @Override
    public void registerUser(UserVO user) {
        userMapper.insertBoard(user);  // 사용자 등록
    }

    @Override
    public List<ImgPathVO> getImgPaths(Criteria cri) {
        return imgPathMapper.selectAll(cri);  // 이미지 경로 리스트 조회
    }

    @Override
    public List<ProductVO> getProducts(Criteria cri) {
        return productMapper.selectAll(cri);  // 상품 리스트 조회
    }

    @Override
    public List<UserVO> getUsers(Criteria cri) {
        return userMapper.selectAll(cri);  // 사용자 리스트 조회
    }
}
