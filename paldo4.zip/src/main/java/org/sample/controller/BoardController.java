package org.sample.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.sample.domain.Criteria;
import org.sample.domain.BoardVO;
import org.sample.domain.Criteria;
import org.sample.domain.PageDTO;
import org.sample.domain.PostDTO;
import org.sample.service.BoardService;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/board")
@RequiredArgsConstructor
@Log4j
public class BoardController {

    private final BoardService boardService;
    
	/*
	 * @GetMapping("/list") public ResponseEntity<List<BoardVO>> getBoardList() {
	 * List<BoardVO> list = boardService.getBoardList(); return
	 * ResponseEntity.ok(list); }
	 */
    @GetMapping("/list")
	public void list(Criteria cri, Model model) {
		log.info("list................."+cri);
		List<BoardVO> list = boardService.getList(cri);
		
		model.addAttribute("list", list);
		model.addAttribute("pageMaker", new PageDTO(cri, boardService.getTotal(cri)));
	}

 // 📌 게시글 상세 조회
    @GetMapping("/{boardId}")
    public ResponseEntity<PostDTO> getBoardDetail(@PathVariable Long boardId) {
        PostDTO boardDetail = boardService.getBoardDetail(boardId);
        return boardDetail != null ? ResponseEntity.ok(boardDetail) : ResponseEntity.notFound().build();
    }

    // 📌 게시글 등록
    @PostMapping
    public ResponseEntity<String> createBoard(@RequestBody BoardVO board) {
        boardService.createBoard(board);
        return ResponseEntity.ok("게시글이 등록되었습니다.");
    }

    // 📌 게시글 수정
    @PutMapping("/{boardId}")
    public ResponseEntity<String> updateBoard(@PathVariable Long boardId, @RequestBody BoardVO board) {
        board.setBoardid(boardId); // 경로 ID → 객체에 세팅
        boardService.updateBoard(board);
        return ResponseEntity.ok("게시글이 수정되었습니다.");
    }

    // 📌 게시글 삭제
    @DeleteMapping("/{boardId}")
    public ResponseEntity<String> deleteBoard(@PathVariable Long boardId) {
        boardService.deleteBoard(boardId);
        return ResponseEntity.ok("게시글이 삭제되었습니다.");
    }
}
